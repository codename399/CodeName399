import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  Renderer2,
  ViewChild,
  computed,
  inject,
  signal,
} from '@angular/core';

import { CommonModule, DecimalPipe } from '@angular/common';

import { ToastService } from '../../../../services/toast.service';
import { AngelOneService } from '../../services/angel-one.service';
import { MarketService } from '../../services/market.service';

import { Gainer } from '../../models/gainer';
import { TradingConfiguration, InstrumentType } from '../../models/trading-configuration';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TooltipDirective } from '../../../../directives/tooltip.directive';

@Component({
  selector: 'app-kuber399',

  standalone: true,

  imports: [CommonModule, TooltipDirective],

  templateUrl: './kuber399.component.html',

  styleUrls: ['./kuber399.component.css'],
})
export class Kuber399Component implements OnInit, AfterViewInit, OnDestroy {
  readonly #angel = inject(AngelOneService);

  readonly #market = inject(MarketService);

  readonly #toast = inject(ToastService);

  readonly #router = inject(Router);

  // ======================================================
  // Dashboard State
  // ======================================================

  gainers = signal<Gainer[]>([]);

  availableCash = signal(0);

  marketStatus = signal('');

  marketTimer = signal('');

  searchText = signal('');

  // ======================================================
  // Configuration
  // ======================================================

  configuration = computed<TradingConfiguration | null>(() =>
    this.#angel.configuration(),
  );

  // ======================================================
  // UI
  // ======================================================

  showSettings = signal(false);

  showPortfolio = signal(false);

  showLogs = signal(false);

  @ViewChild('floatingToggle', { static: true })
  private floatingToggle?: ElementRef<HTMLButtonElement>;

  readonly #renderer = inject(Renderer2);

  #footerResizeObserver?: ResizeObserver;

  readonly #positionFloatingToggle = (): void => {
    const button = this.floatingToggle?.nativeElement;
    const footer = document.querySelector(
      'app-home-footer .home-footer',
    ) as HTMLElement | null;

    if (!button || !footer) {
      return;
    }

    const footerRect = footer.getBoundingClientRect();
    const buttonHeight = button.getBoundingClientRect().height || 46;
    const gap = 12;

    // The button's bottom edge is placed exactly `gap` pixels above the
    // rendered footer's top edge. This is based on the actual viewport
    // geometry, not a guessed mobile footer height.
    const bottom = Math.max(
      8,
      Math.ceil(window.innerHeight - footerRect.top + gap),
    );

    button.style.setProperty('position', 'fixed', 'important');
    button.style.setProperty('top', 'auto', 'important');
    button.style.setProperty('left', 'auto', 'important');
    button.style.setProperty('right', '12px', 'important');
    button.style.setProperty('bottom', `${bottom}px`, 'important');
    button.style.setProperty('z-index', '2147483647', 'important');
    button.style.setProperty('transform', 'none', 'important');
    button.style.setProperty('visibility', 'visible', 'important');
    button.style.setProperty('opacity', '1', 'important');
  };

  readonly columnDefinitions = [
    { key: 'star', label: '⭐', defaultVisible: true },
    { key: 'symbol', label: 'Symbol', defaultVisible: true },
    { key: 'instrumentType', label: 'Type', defaultVisible: true },
    { key: 'exchange', label: 'Exchange', defaultVisible: false },
    { key: 'optionContract', label: 'Option Contract', defaultVisible: false },
    { key: 'oi', label: 'OI', defaultVisible: false },
    { key: 'oiChange', label: 'OI Change %', defaultVisible: false },
    { key: 'pcr', label: 'PCR', defaultVisible: false },
    { key: 'iv', label: 'IV', defaultVisible: false },
    { key: 'delta', label: 'Delta', defaultVisible: false },
    { key: 'gamma', label: 'Gamma', defaultVisible: false },
    { key: 'theta', label: 'Theta', defaultVisible: false },
    { key: 'vega', label: 'Vega', defaultVisible: false },
    { key: 'token', label: 'Token', defaultVisible: false },
    { key: 'prevClose', label: 'Prev Close', defaultVisible: true },
    { key: 'vwap', label: 'VWAP', defaultVisible: false },
    { key: 'ema9', label: 'EMA9', defaultVisible: false },
    { key: 'ema21', label: 'EMA21', defaultVisible: false },
    { key: 'ema50', label: 'EMA50', defaultVisible: false },
    { key: 'ema200', label: 'EMA200', defaultVisible: false },
    { key: 'anchoredVWAP', label: 'Anchored VWAP', defaultVisible: false },
    { key: 'adx', label: 'ADX', defaultVisible: false },
    { key: 'superTrend', label: 'SuperTrend', defaultVisible: false },
    { key: 'superTrendBullish', label: 'ST Bullish', defaultVisible: false },
    { key: 'rsi', label: 'RSI', defaultVisible: false },
    { key: 'volumeMultiplier', label: 'Vol×', defaultVisible: false },
    { key: 'pullbackDistance', label: 'PB%', defaultVisible: false },
    { key: 'distanceFromEMA', label: 'Dist EMA%', defaultVisible: false },
    { key: 'distanceFromVWAP', label: 'Dist VWAP%', defaultVisible: false },
    { key: 'macd', label: 'MACD', defaultVisible: false },
    { key: 'macdSignal', label: 'MACD Sig', defaultVisible: false },
    { key: 'macdHistogram', label: 'MACD Hist', defaultVisible: false },
    {
      key: 'bollingerBandwidth',
      label: 'Boll Bandwidth',
      defaultVisible: false,
    },
    { key: 'score', label: 'Score', defaultVisible: true },
    { key: 'signal', label: 'Signal', defaultVisible: true },
    { key: 'risk', label: 'Risk', defaultVisible: true },
    { key: 'stopLoss', label: 'SL', defaultVisible: true },
    { key: 'targetPrice', label: 'Target', defaultVisible: true },
    { key: 'atr', label: 'ATR', defaultVisible: false },
    { key: 'reason', label: 'Reason', defaultVisible: true },
    { key: 'suggestion', label: 'Suggestion', defaultVisible: true },
    {
      key: 'upperCircuitLimit',
      label: 'Upper Circuit Limit',
      defaultVisible: false,
    },
    {
      key: 'lowerCircuitLimit',
      label: 'Lower Circuit Limit',
      defaultVisible: false,
    },
  ];

  visibleColumns = signal<string[]>([]);
  readonly allowedColumnsByInstrument: Record<InstrumentType, string[]> = {
    Equity: ['star','symbol','instrumentType','exchange','prevClose','vwap','ema9','ema21','ema50','ema200','anchoredVWAP','adx','superTrend','superTrendBullish','rsi','volumeMultiplier','pullbackDistance','distanceFromEMA','distanceFromVWAP','macd','macdSignal','macdHistogram','bollingerBandwidth','score','signal','risk','stopLoss','targetPrice','atr','reason','suggestion','upperCircuitLimit','lowerCircuitLimit'],
    Futures: ['star','symbol','instrumentType','exchange','token','oi','oiChange','prevClose','vwap','ema9','ema21','ema50','ema200','anchoredVWAP','adx','superTrend','superTrendBullish','rsi','volumeMultiplier','pullbackDistance','distanceFromEMA','distanceFromVWAP','macd','macdSignal','macdHistogram','bollingerBandwidth','score','signal','risk','stopLoss','targetPrice','atr','reason','suggestion','upperCircuitLimit','lowerCircuitLimit'],
    Options: ['star','symbol','instrumentType','exchange','optionContract','oi','oiChange','pcr','iv','delta','gamma','theta','vega','token','prevClose','vwap','ema9','ema21','ema50','ema200','anchoredVWAP','adx','superTrend','superTrendBullish','rsi','volumeMultiplier','pullbackDistance','distanceFromEMA','distanceFromVWAP','macd','macdSignal','macdHistogram','bollingerBandwidth','score','signal','risk','stopLoss','targetPrice','atr','reason','suggestion','upperCircuitLimit','lowerCircuitLimit']
  };


  private timerId: any;
  private subscription?: Subscription;

  // ======================================================
  // Computed
  // ======================================================

  subscribedGainers = computed(() =>
    this.gainers().filter((stock) => stock.isSubscribed === true),
  );

  isWaitingForSubscriptions = computed(
    () => this.subscribedGainers().length === 0,
  );

  filteredGainers = computed(() => {
    const search = this.searchText().trim().toLowerCase();

    const filtered = this.subscribedGainers().filter((stock) =>
      stock.symbol.toLowerCase().includes(search),
    );

    return filtered.sort((left, right) => {
      const leftBucket = this.getGainerSortBucket(left);
      const rightBucket = this.getGainerSortBucket(right);

      if (leftBucket !== rightBucket) {
        return leftBucket - rightBucket;
      }

      const scoreDiff = (right.score ?? 0) - (left.score ?? 0);

      if (scoreDiff !== 0) {
        return scoreDiff;
      }

      return left.symbol.localeCompare(right.symbol);
    });
  });

  // ======================================================
  // Computed Dashboard
  // ======================================================

  strategy = computed(() => this.configuration()?.strategy);

  autoTradingEnabled = computed(
    () => this.configuration()?.enableAutoTrading ?? false,
  );

  notificationsEnabled = computed(
    () => this.configuration()?.enableNotification ?? false,
  );

  activeInstrumentType = computed(
    () => this.#angel.selectedInstrumentType(),
  );

  readonly instrumentTypes: { value: InstrumentType; label: string; icon: string }[] = [
    { value: 'Equity', label: 'Equity', icon: 'show_chart' },
    { value: 'Futures', label: 'Futures', icon: 'trending_up' },
    { value: 'Options', label: 'Options', icon: 'account_tree' },
  ];

  selectInstrumentType(type: InstrumentType): void {
    if (type === this.activeInstrumentType()) return;
    this.#angel.selectInstrumentType(type);
    this.gainers.set([]);
    this.visibleColumns.set([]);
    this.loadConfiguration();
    this.loadDashboard();
    void this.subscribeToGainers();
  }

  activeInstrumentSettings = computed(() => {
    const config = this.configuration();
    if (!config) return undefined;
    switch (config.instrumentType) {
      case 'Futures':
        return config.futures;
      case 'Options':
        return config.options;
      default:
        return config.equity;
    }
  });

  riskPercentage = computed(
    () => this.activeInstrumentSettings()?.riskPercentage ?? 0,
  );

  maxDailyTrades = computed(() => {
    const settings = this.activeInstrumentSettings() as any;
    return settings?.maximumDailyTrades ?? 0;
  });

  // ======================================================
  // Lifecycle
  // ======================================================

  ngOnInit(): void {
    this.startMarketTimer();

    this.initializeDashboard();
  }

  ngAfterViewInit(): void {
    const button = this.floatingToggle?.nativeElement;

    if (button && button.parentElement !== document.body) {
      this.#renderer.appendChild(document.body, button);
    }

    // Calculate the position from the REAL footer bounds rather than a
    // hard-coded mobile/desktop offset.
    requestAnimationFrame(() => this.#positionFloatingToggle());

    window.addEventListener('resize', this.#positionFloatingToggle, {
      passive: true,
    });

    const footer = document.querySelector('app-home-footer .home-footer');

    if (footer) {
      this.#footerResizeObserver = new ResizeObserver(() => {
        this.#positionFloatingToggle();
      });

      this.#footerResizeObserver.observe(footer);
    }
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.#positionFloatingToggle);
    this.#footerResizeObserver?.disconnect();

    const button = this.floatingToggle?.nativeElement;

    if (button?.parentElement === document.body) {
      this.#renderer.removeChild(document.body, button);
    }

    if (this.timerId) {
      clearInterval(this.timerId);
    }

    this.subscription?.unsubscribe();
  }

  // ======================================================
  // Initialization
  // ======================================================

  private initializeDashboard(): void {
    this.loadDashboard();

    this.loadConfiguration();

    this.subscribeToGainers();
  }

  // ======================================================
  // Toolbar
  // ======================================================

  toggleSettings(): void {
    this.showSettings.update((v) => !v);
  }

  togglePortfolio(): void {
    this.showPortfolio.update((v) => !v);
  }

  toggleLogs(): void {
    this.showLogs.update((v) => !v);
  }

  toggleColumn(columnKey: string): void {
    const current = this.visibleColumns();
    const next = current.includes(columnKey)
      ? current.filter((key) => key !== columnKey)
      : [...current, columnKey];

    this.visibleColumns.set(next);
    this.persistVisibleColumns(next);
  }

  resetColumns(): void {
    const defaults = this.getDefaultVisibleColumnKeys();

    this.visibleColumns.set(defaults);
    this.persistVisibleColumns(defaults);
  }

  isColumnVisible(columnKey: string): boolean {
    if (!this.allowedColumnsByInstrument[this.activeInstrumentType()]?.includes(columnKey)) return false;
    return this.visibleColumns().includes(columnKey);
  }

  openSettings(): void {
    this.#router.navigate(['/home/trading-settings']);
  }

  // ======================================================
  // Dashboard Summary
  // ======================================================

  private loadDashboard(): void {
    this.#angel

      .getDashboardSummary(this.activeInstrumentType())

      .subscribe({
        next: (summary) => {
          this.availableCash.set(summary.availableCash);
        },

        error: (error) => {
          console.error(
            'Unable to load dashboard',

            error,
          );
        },
      });
  }

  // ======================================================
  // Trading Configuration
  // ======================================================

  private loadConfiguration(): void {
    this.#angel

      .getTradingConfiguration(this.activeInstrumentType())

      .subscribe({
        next: (configuration) => {
          this.applyVisibleColumns(configuration);
        },

        error: (error) => {
          console.error(
            'Unable to load configuration',

            error,
          );

          this.#toast.error('Unable to load trading configuration');
        },
      });
  }

  saveConfiguration(): void {
    const configuration = this.configuration();

    if (!configuration) {
      return;
    }

    const payload: TradingConfiguration = {
      ...configuration,
      visibleColumns: this.visibleColumns(),
    };

    this.#angel

      .saveTradingConfiguration(payload, this.activeInstrumentType())

      .subscribe({
        next: () => {
          this.#toast.success('Configuration saved');
          // Close the left controls panel only after the columns have been
          // successfully saved. Keep it open if the save fails so the user
          // can correct/retry without losing context.
          this.showSettings.set(false);
        },

        error: () => {
          this.#toast.error('Unable to save configuration');
        },
      });
  }

  private applyVisibleColumns(
    configuration: TradingConfiguration | null,
  ): void {
    const configuredColumns = configuration?.visibleColumns?.filter(
      (columnKey) =>
        this.columnDefinitions.some((column) => column.key === columnKey),
    );

    const nextColumns = configuredColumns?.length
      ? configuredColumns
      : this.getDefaultVisibleColumnKeys();

    this.visibleColumns.set(nextColumns);
  }

  private persistVisibleColumns(visibleColumns: string[]): void {
    const configuration = this.configuration();

    if (!configuration) {
      return;
    }

    const payload: TradingConfiguration = {
      ...configuration,
      visibleColumns,
    };

    this.#angel.saveTradingConfiguration(payload, this.activeInstrumentType()).subscribe({
      error: (error) => {
        console.error('Unable to persist visible columns', error);
      },
    });
  }

  private getDefaultVisibleColumnKeys(): string[] {
    return this.columnDefinitions
      .filter((column) => column.defaultVisible)
      .map((column) => column.key);
  }

  // ======================================================
  // SignalR
  // ======================================================

  private async subscribeToGainers(): Promise<void> {
    // Subscribe BEFORE starting SignalR. MarketHub sends the current watchlist
    // from OnConnectedAsync; subscribing afterwards can miss that one-shot
    // snapshot and leave the dashboard empty until the next market update.
    this.subscription?.unsubscribe();
    this.subscription = this.#market.gainers$.subscribe((data: Gainer[]) => {
      // SignalR can deliver a stale SELL after the authoritative snapshot.
      // The UI must never present SELL for an unowned equity, even if an old
      // event arrives after the corrected API snapshot. Owned equities retain
      // SELL because they may legitimately need an exit.
      const normalized = data.map((stock) => this.normalizeGainerForDisplay(stock));
      this.gainers.set(normalized);
    });

    await this.#market.startConnection(this.activeInstrumentType());
  }

  // ======================================================
  // Refresh
  // ======================================================

  refresh(): void {
    // Close the left controls panel first, then refresh the dashboard data.
    this.showSettings.set(false);

    this.loadDashboard();
    this.loadConfiguration();
  }

  // ======================================================
  // Market Timer
  // ======================================================

  private startMarketTimer(): void {
    this.updateMarketTimer();

    this.timerId = setInterval(() => {
      this.updateMarketTimer();
    }, 1000);
  }

  private updateMarketTimer(): void {
    const config = this.configuration();

    if (!config) {
      this.marketStatus.set('LOADING');
      this.marketTimer.set('');
      return;
    }

    const now = new Date();

    const marketOpen = this.getTodayOpen();
    const marketClose = this.getTodayClose();

    if (config.ignoreMarketHours) {
      if (this.isWeekend(now)) {
        this.marketStatus.set('OPEN (Ignored)');
        this.marketTimer.set(
          `Market opens in ${this.formatTime(
            this.getNextMarketOpen(now).getTime() - now.getTime(),
          )}`,
        );
        return;
      }

      if (now < marketOpen) {
        this.marketStatus.set('OPEN (Ignored)');
        this.marketTimer.set(
          `Market opens in ${this.formatTime(
            marketOpen.getTime() - now.getTime(),
          )}`,
        );
        return;
      }

      if (now >= marketOpen && now < marketClose) {
        this.marketStatus.set('OPEN');
        this.marketTimer.set(
          `Market closes in ${this.formatTime(
            marketClose.getTime() - now.getTime(),
          )}`,
        );
        return;
      }

      this.marketStatus.set('OPEN (Ignored)');
      this.marketTimer.set(
        `Market opens in ${this.formatTime(
          this.getNextMarketOpen(now).getTime() - now.getTime(),
        )}`,
      );
      return;
    }

    if (this.isWeekend(now)) {
      this.marketStatus.set('CLOSED');

      this.marketTimer.set(
        `Opens in ${this.formatTime(
          this.getNextMarketOpen(now).getTime() - now.getTime(),
        )}`,
      );

      return;
    }

    if (now < marketOpen) {
      this.marketStatus.set('CLOSED');

      this.marketTimer.set(
        `Opens in ${this.formatTime(marketOpen.getTime() - now.getTime())}`,
      );

      return;
    }

    if (now >= marketOpen && now < marketClose) {
      this.marketStatus.set('OPEN');

      this.marketTimer.set(
        `Closes in ${this.formatTime(marketClose.getTime() - now.getTime())}`,
      );

      return;
    }

    this.marketStatus.set('CLOSED');

    this.marketTimer.set(
      `Opens in ${this.formatTime(
        this.getNextMarketOpen(now).getTime() - now.getTime(),
      )}`,
    );
  }

  // ======================================================
  // Helpers
  // ======================================================

  private normalizeGainerForDisplay(stock: Gainer): Gainer {
    const instrumentType = String(stock.instrumentType ?? 'Equity')
      .trim()
      .toLowerCase();
    const isEquity = instrumentType === '' || instrumentType === 'equity';
    const signal = String(stock.signal ?? '').trim().toUpperCase();

    if (isEquity && !stock.isOwned && signal === 'SELL') {
      return { ...stock, signal: 'HOLD' };
    }

    return stock;
  }

  private getGainerSortBucket(stock: Gainer): number {
    if (stock.isOwned) {
      return 0;
    }

    const signal = (stock.signal ?? '').toUpperCase();

    if (signal === 'BUY' || signal === 'SETUP') {
      return 1;
    }

    return 2;
  }

  private getTodayOpen(): Date {
    const config = this.configuration();

    const date = new Date();

    const [hour, minute] = config?.marketOpenTime?.split(':').map(Number) ?? [
      9, 15,
    ];

    date.setHours(hour, minute, 0, 0);

    return date;
  }

  private getTodayClose(): Date {
    const config = this.configuration();

    const date = new Date();

    const [hour, minute] = config?.marketCloseTime?.split(':').map(Number) ?? [
      15, 30,
    ];

    date.setHours(hour, minute, 0, 0);

    return date;
  }

  private isWeekend(date: Date): boolean {
    return date.getDay() === 0 || date.getDay() === 6;
  }

  private getNextMarketOpen(current: Date): Date {
    const config = this.configuration();

    const next = new Date(current);

    const [hour, minute] = config?.marketOpenTime?.split(':').map(Number) ?? [
      9, 15,
    ];

    next.setHours(hour, minute, 0, 0);

    do {
      next.setDate(next.getDate() + 1);
    } while (this.isWeekend(next));

    return next;
  }

  // ======================================================
  // Countdown
  // ======================================================

  private formatTime(milliseconds: number): string {
    let seconds = Math.max(
      0,

      Math.floor(milliseconds / 1000),
    );

    const days = Math.floor(seconds / 86400);

    seconds %= 86400;

    const hours = Math.floor(seconds / 3600);

    seconds %= 3600;

    const minutes = Math.floor(seconds / 60);

    seconds %= 60;

    const parts: string[] = [];

    if (days > 0) {
      parts.push(`${days}d`);
    }

    if (hours > 0 || days > 0) {
      parts.push(`${hours}h`);
    }

    parts.push(`${minutes}m`);

    parts.push(`${seconds}s`);

    return parts.join(' ');
  }
}
